fprintf('Press any key to play the recording...\n');
pause; 
fprintf('Start recording.\n');
fs=8000; %����Ƶ�� 
recObj = audiorecorder(fs,16,1);
disp('Start speaking.');
recordblocking(recObj, 3);
disp('End of Recording.');

% Play back the recording.
play(recObj);
% Store data in double-precision array.
myRecording = getaudiodata(recObj,'int16');
% filename= 'yuan.wav'
filename ='C:\Users\Smriti Pertor\Desktop\shujufenximoshi.wav';
audiowrite(filename,myRecording,fs);