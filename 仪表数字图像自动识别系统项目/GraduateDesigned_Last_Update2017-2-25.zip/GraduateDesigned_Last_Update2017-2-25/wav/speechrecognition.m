function [tempdata]=speechrecognition(filename)
%Speech Recognition Using Correlation Method
%Write Following Command On Command Window 
%speechrecognition('test.wav')
% close all;
% clc;
% %% luyin
% fprintf('Press any key to play the recording...\n');
% pause; 
% fprintf('Start recording.\n');
% fs=8000; %����Ƶ�� 
% recObj = audiorecorder(fs,16,1);
% disp('Start speaking.');
% recordblocking(recObj, 3);
% disp('End of Recording.');
% 
% % Play back the recording.
% play(recObj);
% % Store data in double-precision array.
% myRecording = getaudiodata(recObj,'int16');
%% shibie 
voice=filename;%audioread(filename);
x=voice;
x=x';
x=x(1,:);
x=x';
y1=audioread('1t010suijizuhe1.wav');
y1=y1';
y1=y1(1,:);
y1=y1';
z1=xcorr(x,y1);
m1=max(z1);
l1=length(z1);
t1=-((l1-1)/2):1:((l1-1)/2);
t1=t1';
figure,
subplot(3,2,1);
plot(t1,z1);
y2=audioread('1to10xianshi2.wav');
y2=y2';
y2=y2(1,:);
y2=y2';
z2=xcorr(x,y2);
m2=max(z2);
l2=length(z2);
t2=-((l2-1)/2):1:((l2-1)/2);
t2=t2';
subplot(3,2,2);
plot(t2,z2);
y3=audioread('daixiaoshudian3.wav');
y3=y3';
y3=y3(1,:);
y3=y3';
z3=xcorr(x,y3);
m3=max(z3);
l3=length(z3);
t3=-((l3-1)/2):1:((l3-1)/2);
t3=t3';
subplot(3,2,3);
plot(t3,z3);
y4=audioread('shujufenximoshi.wav');
y4=y4';
y4=y4(1,:);
y4=y4';
z4=xcorr(x,y4);
m4=max(z4);
l4=length(z4);
t4=-((l4-1)/2):1:((l4-1)/2);
t4=t4';
subplot(3,2,4);
plot(t4,z4);
% y5=audioread('five.wav');
% y5=y5';
% y5=y5(1,:);
% y5=y5';
% z5=xcorr(x,y5);
% m5=max(z5);
% l5=length(z5);
% t5=-((l5-1)/2):1:((l5-1)/2);
% t5=t5';
% subplot(3,2,5);
% plot(t5,z5);
% m6=100;
% a=[m1 m2 m3 m4 m5];
% m4=100;
a=[m1 m2 m3 m4];
m=max(a);
h=audioread('allow.wav');
soundsc(h,20000)    %ʶ�����
pause(0.5);
if m==m1
    soundsc(audioread('moshiyi.wav'),8000)
%         soundsc(h,50000)    %ʶ�����
        tempdata=1;
elseif m==m2
    soundsc(audioread('moshier.wav'),8000)
%         soundsc(h,20000)
        tempdata=2;
elseif m==m3
    soundsc(audioread('moshisan.wav'),8000)
%         soundsc(h,50000)
        tempdata=3;
elseif m==m4
    soundsc(audioread('moshisi.wav'),8000)
%         soundsc(h,50000)
        tempdata=4;
else soundsc(audioread('weishibie.wav'),8000)
   tempdata=6;
end