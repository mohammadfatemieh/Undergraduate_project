 function varargout = biyesheji0409(varargin)
% BIYESHEJI0409 MATLAB code for biyesheji0409.fig
%      BIYESHEJI0409, by itself, creates a new BIYESHEJI0409 or raises the existing
%      singleton*.
%
%      H = BIYESHEJI0409 returns the handle to a new BIYESHEJI0409 or the handle to
%      the existing singleton*.
%
%      BIYESHEJI0409('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BIYESHEJI0409.M with the given input arguments.
%
%      BIYESHEJI0409('Property','Value',...) creates a new BIYESHEJI0409 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before biyesheji0409_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to biyesheji0409_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help biyesheji0409

% Last Modified by GUIDE v2.5 11-Jun-2016 10:00:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @biyesheji0409_OpeningFcn, ...
                   'gui_OutputFcn',  @biyesheji0409_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% ha=axes('units','normalized','position',[0 0 1 1]);
% uistack(ha,'down')   % ���ݿؼ��뱳��ͼƬ�Ĺ�ϵ��������Ϊdown/Top/bottom��
% II=imread('beijing.jpg');
% image(II)
% colormap gray
% set(ha,'handlevisibility','off','visible','off');
% End initialization code - DO NOT EDIT


% --- Executes just before biyesheji0409 is made visible.
function biyesheji0409_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to biyesheji0409 (see VARARGIN)

% Choose default command line output for biyesheji0409
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes biyesheji0409 wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%% ����ͼ�񱳾�
ha=axes('units','normalized','position',[0 0 1 1]);
uistack(ha,'down')   % ���ݿؼ��뱳��ͼƬ�Ĺ�ϵ��������Ϊdown/Top/bottom��
II=imread('beijing.jpg');
image(II);
colormap gray
set(ha,'handlevisibility','off','visible','off');
set(handles.Rate, 'value',6);
set(handles.shujufx, 'value', 0);
set(handles.isHexDisp, 'value', 0);
%% ʧ�ܲ�����ť
    set(handles.ImageLoad, 'Enable', 'off');set(handles.fenge, 'Enable', 'off');set(handles.ErZhi, 'Enable', 'off');set(handles.ShiBie, 'Enable', 'off');
    set(handles.pushbutton19, 'Enable', 'off');set(handles.imcapturebotn, 'Enable', 'off');
    set(handles.IPComOpen, 'Enable', 'off');set(handles.pushbutton17, 'Enable', 'off');
    set(handles.LPCtimes, 'Enable', 'off');
    global zhi1;
    zhi1=0;
% --- Outputs from this function are returned to the command line.
function varargout = biyesheji0409_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

 
% --- Executes on button press in ImageLoad.
function ImageLoad_Callback(hObject, eventdata, handles)
% hObject    handle to ImageLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global z;   %ͼ�����
global Imagecapflag;    %����ͷ�򿪱�־��ʹ����ͷ�˳�
val=get(handles.IPSelectPop,'value');   %�õ���ѡ���ֵ

if val~=2       %if--���ļ�����
    msgbox('Please Choice Camera Select "Local Image!"')
else
    Imagecapflag=1;
    [filename pathname]=uigetfile({'*.png';'*.jpg';'*.jpeg';'*.*'},'ѡ��ͼƬ');
    handles.path=[pathname filename];
    if ~ischar(handles.path)
        disp('û��ȷѡ���ļ������ѡ��');
        return ;
    end
    handles.image1=imread(handles.path);        %��ȡͼ���ļ�
    z=handles.image1;    
    axes(handles.axes1);    %ͼƬ��ʾ
    imshow(handles.image1);
end
% k=mean(mean(rgb2gray(handles.image1)))





% --- Executes on button press in ShiBie.
function ShiBie_Callback(hObject, eventdata, handles)
% hObject    handle to ShiBie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%����ȡ��ͼƬ��һ���ָ��һ�����ַ�
%% �ַ�ʶ���㷨
%�Ӻ��ڶ���ַ�ͼ�зָ��һ�������ַ�
% global image1;
global picture;
global numall;
[pict1,pict2,pict3,pict4,pict5,pict6]=cutup2pic(picture);

axes(handles.axes4);
axes('position',[0.31,0.24,0.1,0.1]);
imshow(pict1);
axes('position',[0.36,0.24,0.1,0.1]);
imshow(pict2);
axes('position',[0.41,0.24,0.1,0.1]);
imshow(pict3);
axes('position',[0.46,0.24,0.1,0.1]);
imshow(pict4);
axes('position',[0.51,0.24,0.1,0.1]);
imshow(pict5);
axes('position',[0.56,0.24,0.1,0.1]);
imshow(pict6);


% figure();
% subplot(241)
% imshow(pict1);
% subplot(242)
% imshow(pict2);
% subplot(243)
% imshow(pict3);
% subplot(244)
% imshow(pict4);
% subplot(245)
% imshow(pict5);
% subplot(246)
% imshow(pict6);
% %% �ַ��ı���ʾ  
% %8�����Զ�ͼƬ���зָ�ʶ��
% [m,n]=size(pict1);
% row=ceil(m/3);
% colum=ceil(n/2);
% pictone(1,:,:)=pict1(1:row,1:colum);
% pictone(2,:,:)=pict1(1:row,colum+1:n);
% pictone(3,:,:)=pict1(row:2*row-1,1:colum);
% pictone(4,:,:)=pict1(row:2*row-1,colum+1:n);
% pictone(5,:,:)=pict1(2*row:m,1:colum);
% pictone(6,:,:)=pict1(2*row:m,colum+1:n);
% 
% %��һ����
% [~,m,n]=size(pictone(1,:,:));
% smg8prow=zeros(1,6);
% smg8pcolum=zeros(1,6);
% flagrow=zeros(6,m);
% flagcolum=zeros(6,n);
% 
% for K=1:6
%     for row=3:m
%        flagrow(K,row)=sum(pictone(K,row,:));  %�������  
%        if flagrow(K,row)>15 && flagrow(K,row-1)>15 && flagrow(K,row-2)>15
%            smg8prow(K)=1;
%        end
%     end   
%     
%     for colum=3:n
%        flagcolum(K,colum)=sum(pictone(K,:,colum));  %�������   
%        if flagcolum(K,colum)>15 && flagcolum(K,colum-1)>15 && flagcolum(K,colum-2)>15
%           smg8pcolum(K)=1; 
%        end 
%     end    
% end
% 
% % %      a|
% % %   f|-----|b
% % % _  |--g--|     _
% % %   e|_____|c .dp 
% % %      d|
% a=smg8prow(1)+smg8prow(2)-1; %���a����ʾ��a=2���������
% b=smg8pcolum(2)+smg8pcolum(4)-1;
% c=smg8pcolum(4)+smg8pcolum(6)-1;
% d=smg8prow(5)+smg8prow(6)-1;
% e=smg8pcolum(3)+smg8pcolum(5)-1;
% f=smg8pcolum(1)+smg8pcolum(3)-1;
% g=smg8prow(3)+smg8prow(4)-1;
%       
% numeric =[a b c d e f g];
% numeric0=[1 1 1 1 1 1 0];
% numeric1=[0 1 1 0 0 0 0];
% numeric2=[1 0 0 1 1 0 1];
% numeric3=[1 1 1 1 0 0 1];
% numeric4=[0 1 1 0 0 1 1];
% numeric5=[1 0 1 1 0 1 1];
% numeric6=[1 0 1 1 1 1 1];
% numeric7=[1 1 1 0 0 0 0];
% numeric8=[1 1 1 1 1 1 1];
% numeric9=[1 1 1 0 0 1 1];
% 
% if (sum(numeric0 == numeric))==7
%         num=0;
% elseif (sum(numeric1 == numeric))==7
%     num=1;
% elseif (sum(numeric2 == numeric))==7
%     num=2;
% elseif (sum(numeric3 == numeric))==7
%     num=3;
% elseif (sum(numeric4 == numeric))==7
%     num=4;
% elseif (sum(numeric5 == numeric))==7
%     num=5;
% elseif (sum(numeric6 == numeric))==7
%     num=6;
% elseif (sum(numeric7 == numeric))==7
%     num=7;
% elseif (sum(numeric8 == numeric))==7
%     num=8;
% elseif (sum(numeric9 == numeric))==7    
%    num=9;
%     else 
%         num=10;
% end
%----------------������-------------------------------------------
num1=image2num(pict1,1);
num2=image2num(pict2,1);
num3=image2num(pict3,1);
num4=image2num(pict4,1);
num5=image2num(pict5,1);
num6=image2num(pict6,1);
num=num1*1000+num2*100+num3*10+num4+num5*0.1+num6*0.01;


set(handles.edit1,'String',num);
%% д��excel
filename = 'image2num.xlsx';
[numericData, ~, raw] = xlsread(filename);
[rowN, ~]=size(raw);
Data=['ֵ' num2str(num)];
sheet=1;
xlsRange=['C1',num2str(rowN+1)];
xlswrite(filename,Data,sheet,xlsRange);

% num=[num1,num2,num3,num4,num5,num6];
% set(handles.edit1,'String',num2str(num));
% a=str2num(get(handles.edit1,'string')); 
%% ���ݷ���
 set(handles.CommentTxt,'visible','off');


%% ��������
% userPrompt = 'The Pattern recognition character information is:';
% �������ݵ���
% titleBar = 'Text to Speech';
% defaultString = 'Hello World!  MATLAB is an awesome program!';
% caUserInput = inputdlg(userPrompt, titleBar, 1, {defaultString});
% 
% if isempty(caUserInput)
% 	return;
% end; % Bail out if they clicked Cancel.

userPrompt = 'ģʽʶ����:';
caUserInput=num2str(num);

caUserInput=[userPrompt caUserInput]
% % caUserInput = char(caUserInput); % Convert from cell to string.
% sp=actxserver('SAPI.SpVoice');
% sp.Speak(caUserInput);
tts(caUserInput);%�����������������ʵ��
    %%  �ⲿ�ֽ����еڶ�����
     %% ���ݴ���8000�򱨾�
 if num>8000
     
     %      alert_led(3);
     [A,map]=imread('www.jpg', 'frames', 'all');
     axes(handles.boxing);
     imshow(A(:,:,:,1),map);pause(0.5);
     imshow(A(:,:,:,2),map);pause(0.5);
     imshow(A(:,:,:,3),map);pause(0.5);
     imshow(A(:,:,:,4),map);pause(0.5);
     imshow(A(:,:,:,5),map);pause(0.5);
     imshow(A(:,:,:,6),map);
     cla(handles.boxing);
 end
    %%  ���ݷ������Ʋ�������
    val=get(handles.shujufx,'value');
    if val==1
%         cla(handles.boxing);  %���Ʋ���ǰ���ͼ����Ϣ
        axes(handles.boxing);  %�������������
        
        numall=[numall num];
        
%         plot(handles.boxing,1:length(numall),numall,'b--o');%��������boxing����ʾ����
%         hold on;
        
        %�������
        LPCval=get(handles.LPCtimes,'value')
        if(LPCval==1)
            numfit=polyfit(1:length(numall),numall,1);
            str=['y=' '(' num2str(numfit(1)) ')' '*x+' '(' num2str(numfit(2)) ')'];
            x1=1:length(numall);
            y1=numfit(1)*x1.^1+numfit(2);            
        elseif(LPCval==2)
            numfit=polyfit(1:length(numall),numall,2);
            str=['y=' '(' num2str(numfit(1)) ')' '*x^2+' '(' num2str(numfit(2)) ')' '*x+' '(' num2str(numfit(3)) ')'];
            x1=1:length(numall);
            y1=numfit(1)*x1.^2+numfit(2)*x1.^1+numfit(3);
        elseif(LPCval==3)
            numfit=polyfit(1:length(numall),numall,3);
            str=['y=' '(' num2str(numfit(1)) ')' '*x^3+' '(' num2str(numfit(2)) ')' '*x^2+' '(' num2str(numfit(2)) ')' '*x+' '(' num2str(numfit(3)) ')'];
            x1=1:length(numall);
            y1=numfit(1)*x1.^3+numfit(2)*x1.^2+numfit(3)*x1.^1+numfit(4);
        else 
            str='';
        end
        
        
        plot(handles.boxing,x1,y1,1:length(numall),numall,'b--o');%��������boxing����ʾ����    
%         plot(x,y1,'-ro',x,y2,'-.b')
        legend(handles.boxing,'�������','ԭʼ����','Location','northoutside','Orientation','horizontal')
            %��ʾ����
        set(handles.edit7,'String',str);
    end

% --- Executes on button press in ErZhi.
function ErZhi_Callback(hObject, eventdata, handles)
% hObject    handle to ErZhi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% ��ֵ��
global image1;
global picture;
% % if length(size(z))==3
% %     picture=rgb2gray(z);
% % end
% % axes(handles.axeszf);
% % imhist(picture);
% % % [row columns]=size(picture)   %size binary
% % picture=im2bw(picture,0.2);%ͼ���ֵ��
% % axes(handles.axes2);
% % %figure();
% % imshow(picture);
[m,n]=size(image1);
if n~=2
imagegray=rgb2gray(image1);
end
picture=im2bw(image1,0.2);  
%% imge show
axes(handles.axes2);   
imshow(imagegray);  %show gray image

axes(handles.axeszf);
%imhist(imagegray);  %show imhist
imhist(histeq(imagegray));
axes(handles.axes3);    
imshow(picture);    %show bw image


% --- Executes on button press in EXT1.
function EXT1_Callback(hObject, eventdata, handles)
% hObject    handle to EXT1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% �رղ��˳�
global Imagecapflag;
global idx;
idx=100;
Imagecapflag=1;
while(Imagecapflag==5)
    pause(1);
end
close all
clear all
close(gcf);


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function ErZhi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ErZhi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in fenge.
function fenge_Callback(hObject, eventdata, handles)
% hObject    handle to fenge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% ͼ��ָ�ȥ����
global z;       %ȫ�ֵı����������������ͼƬ
global image1;
%�Զ�ֵ�����ͼ���������λ����ʾ��axes3��
%���Ե�һ�ַ����ֶ�ѡ��ָ���������㷨
% [159.625748502994 168.440119760479;157.158682634731 388.008982035928;1023.09880239521 402.811377245509;1042.83532934132 193.110778443114]
%��������ѡ��
% c=[159 157 1023 1042];
% r=[168 388 402 193];
% BW = roipoly(picture,c,r);
% [row columns]=size(picture);   %size binary
% for i=1:row
%    for j=1:columns
%        BW1(i,j)=BW(i,j)&picture(i,j);  
%    end
% end
% BW2=BW1(168:402,159:1042);  %����ָ��Զ������ط�Χ��
% imwrite(BW2,'myGray.png');
% axes(handles.axes3);
% imshow(BW2);%����ȫ��Ŀ������
%�ָ��㷨

% image1=zonelim(BW2); %�ַ�����ȷ��ȡ
% axes(handles.axes3);
% imshow(image1);%����ȫ��Ŀ������
% imwrite(image1,'picture1.jpg');

%----------------------�㷨�Ľ�-------------------------------------------------
Rmin=180;Rmax=256;Gmin=10;Gmax=100;Bmin=40;Bmax=200;
image1=rgb2roicollect(z,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����λ�㷨rgb2roicollect
axes(handles.axes2);    %�ָ���ͼƬ��ʾ
imshow(image1);%����ȫ��Ŀ������

% pic=im2bw(image1,0.2);  %�ָ���ͼƬ
% axes(handles.axes3);    %�ָ���ͼƬ��ʾ
% imshow(pic);%����ȫ��Ŀ������
% --- Executes on button press in TEXTSHOW.
function TEXTSHOW_Callback(hObject, eventdata, handles)
% hObject    handle to TEXTSHOW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in excelWrite.
function excelWrite_Callback(hObject, eventdata, handles)
% hObject    handle to excelWrite (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in imcapturebotn.
function imcapturebotn_Callback(hObject, eventdata, handles)
% hObject    handle to imcapturebotn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Imagecapflag;
global VediorgbImage;
global idx;
global zhi1;
 set(handles.CommentTxt,'visible','off');
val=get(handles.IPSelectPop,'value');   %��ȡѡ�����ݿ��Ƿ�ѡ������ͷ
if val~=4
    msgbox('Please Choice Camera Select "WebCamera !"')
else
    clear z;    
    try
        obj=webcam('USB2.0 PC CAMERA');%����ͷѡ��        
    catch       
        obj=webcam('USB2.0 UVC HD Webcam');
    end    
    Imagecapflag=3;
    
    %% ��ʼ��
    if zhi1==0
        zhi1=0.5;
    end
%     pause(1);   %��ʱ1s
    cla(handles.axeszf);
    cla(handles.axes6);
    cla(handles.boxing);
    VediorgbImage = snapshot(obj);
                                                     figure(2),imshow(VediorgbImage);title('ԭʼͼ��');%//����ӵ�
    Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
    Rpic=rgb2roicollect(VediorgbImage,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ
    pic=Rpic(:,:,1);
                                                     figure(3),imshow(pic);title('����Ȥ������ȡ���');%//����ӵ�
%     image1=im2bw(pic,0.5);  %����ҶȻ���

image1=im2bw(pic,zhi1);  %����ҶȻ���
%     cq=cuoqie(image1);    %���б任����ʱû�е�
                                                       figure(4),imshow(image1);title('����Ȥ�����ֵ�����');%//����ӵ�
    k=0;
    for idx=1:5
        pause(1);
        VediorgbImage = snapshot(obj);
        Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
        Rpic=rgb2roicollect(VediorgbImage,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ
        pic=Rpic(:,:,1);
        axes(handles.axeszf);
        imhist(histeq(rgb2gray(Rpic)));
%         image1=im2bw(pic,0.5);
           zhi1=graythresh(pic);
        image1=im2bw(pic,zhi1);
        a=rotate2rci(image1);   %����ת�Ƕȣ����������ת�ĽǶ�
        k=k+a;
    end
    a=k/5.0;    %����ͼ���ȡ����ת�Ƕ�ƽ��ֵ
    a=0;
    numstore=0;
     for idx = 1:20
        VediorgbImage = snapshot(obj);
        axes(handles.axes1);
        imshow(VediorgbImage);
                                                        figure(2),imshow(VediorgbImage);title('ԭʼͼ��');%//����ӵ�
        VediorgbImage1(:,:,1)=imrotate(VediorgbImage(:,:,1),a);
        VediorgbImage1(:,:,2)=imrotate(VediorgbImage(:,:,2),a);
        VediorgbImage1(:,:,3)=imrotate(VediorgbImage(:,:,3),a);
                                                        figure(5),imshow(VediorgbImage1);title('ԭʼ�ǶȽ������ͼ��');%//����ӵ�
        if Imagecapflag == 1        %��־λ��⣬��⵽��־λ���˳���
            clear obj;
            Imagecapflag=5;
            break;
        end
        Imagecapflag=0;
        %         try
        %����ת���ͼƬ���� object recongnize detect
        Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
        Rpic=rgb2roicollect(VediorgbImage1,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ
        axes(handles.axes2);
        imshow(Rpic);
                                                                    figure(3),imshow(Rpic);title('����Ȥ������ȡ��');%//����ӵ�
        pic=Rpic(:,:,1);
        axes(handles.axeszf);
        imhist(histeq(rgb2gray(Rpic)));
        %             image1=im2bw(pic,0.5);
%         image1=im2bw(pic,0.5);
        zhi1=graythresh(pic);
        image1=im2bw(pic,zhi1);
        image1=im2bw(pic,zhi1);
        J1=image1;
        axes(handles.axes3);
        imshow(J1);
                                                        figure(4),imshow(J1);title('��ֵ�����');%//����ӵ�
        %% ��������ȡ���ͼ��ȥ��Ϊ�ָ���ı�ü�
        [m,~]=size(J1);
        J2=zeros(m,1);
        for i=1:m
            J2(i)=sum(J1(i,:));
            if (J2(i)>3)
                break;
            end
        end
        
        for j=m:-1:i
            J2(j)=sum(J1(i,:));
            if (J2(j)>3)
                break;
            end
        end
        image2=J1(i:j,:);
        
        %% ������ͷͼƬ��ר�ŵĴ���
        [pict1,pict2,pict3,pict4,pict5]=cutup2picdel(image2);
        %
        %             cqpict1=imtransform(pict1,cq);
        %             cqpict2=imtransform(pict2,cq);
        %             cqpict3=imtransform(pict3,cq);
        %             cqpict4=imtransform(pict4,cq);
        %             cqpict5=imtransform(pict5,cq);
        %             [pict1,pict2,pict3,pict4,pict5]=cutup2pic(image1);
        %         set(handles.edit1,'String',' ');
        %             set(handles.edit1,'String','-------');
        %             pause(1);
        %             axes(handles.axes4);
        %             axes('position',[0.25,0.24,0.1,0.1]);
        %             imshow(pict1);
        %             axes('position',[0.3,0.24,0.1,0.1]);
        %             imshow(pict2);
        %             axes('position',[0.35,0.24,0.1,0.1]);
        %             imshow(pict3);
        %             axes('position',[0.4,0.24,0.1,0.1]);
        %             imshow(pict4);
        %             axes('position',[0.45,0.24,0.1,0.1]);
        %             imshow(pict5);
        % %             num1=image2num1(imresize(cqpict1,[179 100]),1);
        % %             num2=image2num1(imresize(cqpict2,[179 100]),1);
        % %             num3=image2num1(imresize(cqpict3,[179 100]),1);
        % %             num4=image2num1(imresize(cqpict4,[179 100]),1);
        % %             num5=image2num1(imresize(cqpict5,[179 100]),1);
        set(handles.edit1,'String','');
        %             num1=image2num1(imresize(pict1,[179 100]),2);
        %             num2=image2num1(imresize(pict2,[179 100]),2);
        %             num3=image2num1(imresize(pict3,[179 100]),2);
        %             num4=image2num1(imresize(pict4,[179 100]),2);
        %             num5=image2num1(imresize(pict5,[179 100]),2);
        point1=0;
        [num1,point1]=ImC2numORC(pict1);
        [num2,point2]=ImC2numORC(pict2);
        [num3,point3]=ImC2numORC(pict3);
        [num4,point4]=ImC2numORC(pict4);
        [num5,point5]=ImC2numORC(pict5);
        charc1=num2str(num1);
        charc2=num2str(num2);
        charc3=num2str(num3);
        charc4=num2str(num4);
        charc5=num2str(num5);
        if point1==1
            str=[charc1 '.' charc2 charc3 charc4 charc5];
            num_c=num1+num2*0.1+num3*0.01+num4*0.001+num5*0.0001;%cuoqie(pict1)
            
        elseif point2==1
            str=[charc1 charc2 '.' charc3 charc4 charc5];
            num_c=num1*10+num2+num3*0.1+num4*0.01+num5*0.001;%cuoqie(pict1)
        elseif point3==1
            str=[charc1 charc2 charc3 '.' charc4 charc5];
            num_c=num1*100+num2*10+num3+num4*0.1+num5*0.01;%cuoqie(pict1)
        elseif point4==1
            str=[charc1 charc2 charc3 charc4 '.' charc5];
            num_c=num1*10000+num2*1000+num3*100+num4*10+num5;%cuoqie(pict1)
        else
            str=[charc1 charc2 charc3 charc4 charc5];
            num_c=num1*10000+num2*1000+num3*100+num4*10+num5;%cuoqie(pict1)
        end
        
        %             num_c=num1*10000+num2*1000+num3*100+num4*10+num5;%cuoqie(pict1)
        %             str = num2str(num_c);
        %             str1= [num1 num2 num3 num4 num5];
        %             str=num2str(str1);
        set(handles.edit1,'String',str);
        
        axes(handles.axes4);
        axes('position',[0.31,0.24,0.1,0.1]);
        imshow(pict1);
        axes('position',[0.37,0.24,0.1,0.1]);
        imshow(pict2);
        axes('position',[0.44,0.24,0.1,0.1]);
        imshow(pict3);
        axes('position',[0.50,0.24,0.1,0.1]);
        imshow(pict4);
        axes('position',[0.56,0.24,0.1,0.1]);
        imshow(pict5);
        pause(1);
        try
            if (Imagecapflag == 1)
                clear obj;
                Imagecapflag=5;
                break;
            end
        catch
            break;
        end
        numstore=[numstore num_c];
    end
    %%  �ⲿ�ֽ����еڶ�����
    %%  ���ݷ������Ʋ�������
        %% ���λ��Ƴ�ʼ��
    cla(handles.boxing);
    axes(handles.boxing);
    % hold on
    y=numstore;
    num1=length(y);
    x=1:num1;
    val=get(handles.shujufx,'value');
    if val==1
        
        %�������
        num=polyfit(x,y,2);
        y1=num(1)*x.^2-num(2)*x+num(3);  %������Ϸ���
        plot(handles.boxing,x,y1,x,y,'b--o');%��������boxing����ʾ����
        legend(handles.boxing,'�������','ԭʼ����','Location','northoutside','Orientation','horizontal')
        %��ʾ����
        str=['y=(' num2str(num(1)) ')*x.^2+(' num2str(num(2)) ')*x+(' num2str(num(3))];
        set(handles.edit7,'String',str);
    end
    
    
end
% % --- Executes on button press in jiaozhun.
% function jiaozhun_Callback(hObject, eventdata, handles)
% % hObject    handle to jiaozhun (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global Imagecapflag;
% global VediorgbImage;
% global idx;
% val=get(handles.IPSelectPop,'value');
% if val~=3
%     msgbox('Please Choice Camera Select "WebCamera !"')
% else
%     try
%         obj=webcam('USB2.0 PC CAMERA');%����ͷѡ��
%     catch
%         obj=webcam('USB2.0 UVC HD Webcam');
%     end
%     Imagecapflag=4;
%     for idx = 1:70
%         % Acquire a single image.
%         VediorgbImage = snapshot(obj);
% %         axes(handles.axes6);
%         axes(handles.axeszf);
%         imshow(VediorgbImage);
%         if (Imagecapflag == 1)||(Imagecapflag==3)
%             clear obj;
%             Imagecapflag=5;
%             break;
%         end
%     end    
% end
% 
% % axes(handles.axes6);
% axes(handles.axeszf);
% imshow(VediorgbImage);
% % axes(handles.axes1);
% % ��ͼ������λ
% 


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function Recvedit_Callback(hObject, eventdata, handles)
% hObject    handle to Recvedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Recvedit as text
%        str2double(get(hObject,'String')) returns contents of Recvedit as a double


% --- Executes during object creation, after setting all properties.
function Recvedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Recvedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SerialOpen.

function Com_Callback(hObject, eventdata, handles)

function SerialOpen_Callback(hObject, eventdata, handles)
% hObject    handle to SerialOpen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 %% �����¡��򿪴��ڡ���ť���򿪴���
if get(hObject, 'value')    %����ǰ���������ֵΪ1-----hObjectΪ��ť����ľ��    
    com_n = sprintf('COM%d', get(handles.Com, 'value'));%% ��ȡ���ڵĶ˿���  
    rates = [300 600 1200 2400 4800 9600 19200 38400 43000 56000 57600 115200];  
    baud_rate = rates(get(handles.Rate, 'value'));   %% ��ȡ������
    
    switch get(handles.jiaoyan, 'value') %% ��ȡУ��λ����
        case 1
            jiaoyan = 'none';
        case 2
            jiaoyan = 'odd';
        case 3
            jiaoyan = 'even';
    end   
    data_bits = 5 + get(handles.data_bits, 'value'); %% ��ȡ����λ����   
    stop_bits = get(handles.stop_bits, 'value'); %% ��ȡֹͣλ����   
    scom = serial(com_n); %% �������ڶ���    
    set(scom, 'BaudRate', baud_rate, 'Parity', jiaoyan, 'DataBits',...%% ���ô������ԣ�ָ����ص�����
        data_bits, 'StopBits', stop_bits, 'BytesAvailableFcnCount', 10,...
        'BytesAvailableFcnMode', 'byte', 'BytesAvailableFcn', {@bytes, handles},... %ִ�з������ݵĻص�������bytes
        'TimerPeriod', 0.05, 'timerfcn', {@dataDisp, handles});     %����ʱ�䵽��ִ��dataDisp����    
    set(handles.figure1, 'UserData', scom);%% �����ڶ���ľ����Ϊ�û����ݣ����봰�ڶ���
    %% ���Դ򿪴���
    try
        fopen(scom);  %�򿪴���
        msgbox('���ڴ򿪳ɹ���');
        set(handles.CommentTxt,'visible','off');
    catch   % �����ڴ�ʧ�ܣ���ʾ�����ڲ��ɻ�ã���
        msgbox('���ڲ��ɻ�ã�');
        set(hObject, 'value', 0);  %���𱾰�ť 
        return;
    end
    
    %% �򿪴��ں��������ڷ������ݣ���ս�����ʾ������������״ָ̬ʾ�ƣ�
    %% �����ı���ť�ı�Ϊ���رմ��ڡ�
    set(handles.Recvedit, 'string', ''); %��ս�����ʾ��
    set(hObject, 'String', '�رմ���');  %���ñ���ť�ı�Ϊ���رմ��ڡ�
else  %���رմ���
    %% ֹͣ��ɾ����ʱ��
    t = timerfind;
    if ~isempty(t)
        stop(t);
        delete(t);
    end
    %% ֹͣ��ɾ�����ڶ���
    scoms = instrfind;
    stopasync(scoms);
    fclose(scoms);
    delete(scoms);
    msgbox('�ѹرգ�');
    set(hObject, 'String', '�򿪴���');  %���ñ���ť�ı�Ϊ���򿪴��ڡ�
end


function dataDisp(obj, event, handles)
global value
%	���ڵ�TimerFcn�ص�����
%   ����������ʾ
%% ��ȡ����
% strRec = '';
hasData = getappdata(handles.figure1, 'hasData'); %�����Ƿ��յ�����
strRec = getappdata(handles.figure1, 'strRec');   %�������ݵ��ַ�����ʽ����ʱ��ʾ������
numRec = getappdata(handles.figure1, 'numRec');   %���ڽ��յ������ݸ���
%% ������û�н��յ����ݣ��ȳ��Խ��մ�������
if ~hasData
    bytes(obj, event, handles);
end
%% �����������ݣ���ʾ��������
if hasData
    %% ��������ʾģ��ӻ�����
    %% ��ִ����ʾ����ģ��ʱ�������ܴ������ݣ�����ִ��BytesAvailableFcn�ص�����
    setappdata(handles.figure1, 'isShow', true); 
    setappdata(handles.figure1, 'strRec', strRec);

    %% ��ʾ����
%     set(handles.xianshi, 'string', strRec);
%     set(handles.Recvedit, 'string', strRec);
%�����.txt�ļ�    
% [FileName PathName]=uiputfile({'*.txt','Txt Files(*.txt)';'*.*','All Files(*.*)'},'choose a File');
% ysw= [PathName FileName];
% dlmwrite(ysw, strRec,'delimiter','\t');
% save ysw strRec
% save(char(ysw), 'strRec')

% value=get(handles.xianshi,'string');
set(handles.Recvedit, 'string', strRec);
% save('ysw.txt','value');
% save('ysw.mat','value');
% 
% if isempty(value)
%     msgbox( '��ǰû�н��յ�����','��ʾ');
%     fclose(gcf)
% else value
if value 
    value1=textscan(value,'%s'); %��ȡ���е�����
    % value=textscan(ysw,'%s'); %��ȡ���е�����
    value2=value1{1};%�õ����ݣ��洢��value1��
    num=length(value2);
    val=[];
    i=1;
    for ii=1:2:num-1
        val=[val,hex2dec(strcat(value2{ii},value2{ii+1}))];%ת��
        time(i) = 0.05*ii;
        i=i+1;
    end
    axes(handles.plotAD);
   
%     plot(handles.plotAD,time,val);
%     hold on
%     close(figure(1))
%   plot(val,'DisplayName','val','YDataSource','val');
%   figure(gcf)
%   set(gcf,'currentaxes',handles.plotAD);   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %% ���½��ռ���
%      set(handles.rec,'string','numRec' );%
    %% ����hasData��־���������������Ѿ���ʾ
    setappdata(handles.figure1, 'hasData', false);
    %% ��������ʾģ�����
    setappdata(handles.figure1, 'isShow', false);
else 
     bytes(obj, event, handles);
end

function bytes(obj, ~, handles)
%   ���ڵ�BytesAvailableFcn�ص�����
%   ���ڽ�������
%% ��ȡ����
strRec = getappdata(handles.figure1, 'strRec'); %��ȡ����Ҫ��ʾ������
numRec = getappdata(handles.figure1, 'numRec'); %��ȡ�����ѽ������ݵĸ���
% isStopDisp = getappdata(handles.figure1, 'isStopDisp'); %�Ƿ����ˡ�ֹͣ��ʾ����ť
isHexDisp=get(handles.isHexDisp,'value');
isShow = getappdata(handles.figure1, 'isShow');  %�Ƿ�����ִ����ʾ���ݲ���
%% ������ִ��������ʾ�������ݲ����մ�������
if isShow
    return;
end
%% ��ȡ���ڿɻ�ȡ�����ݸ���
n = get(obj, 'BytesAvailable');
%% �����������ݣ�������������
if n
    %% ����hasData����������������������Ҫ��ʾ
    setappdata(handles.figure1, 'hasData', true);
    %% ��ȡ��������
    a = fread(obj, n, 'uchar');
    %% ��û��ֹͣ��ʾ�������յ������ݽ��������׼����ʾ
%     if ~isStopDisp 
        %% ���ݽ�����ʾ��״̬����������ΪҪ��ʾ���ַ���
        if ~isHexDisp 
            c = char(a');
        else
            strHex = dec2hex(a')';
            strHex2 = [strHex; blanks(size(a, 1))];
            c = strHex2(:)';
            

        end
        %% �����ѽ��յ����ݸ���
        size(a, 1)
        numRec = numRec + size(a, 1);
        if numRec>10
            strRec=0;
            numRec=0;
        end
        %% ����Ҫ��ʾ���ַ���
        strRec = [strRec c];
        set(handles.rec,'string',size(strRec,2));
        
        %% ���Ʋ���
        if isHexDisp
            k=str2num(strRec);
            y=length(k);
            %         handles.axes2
            axes(handles.boxing);
            %         PLOT(AX,...) plots into the axes with handle AX.
            plot(handles.boxing,1:y,k);
            LPCval=get(handles.LPCtimes,'value');
            if(LPCval==1)
                numfit=polyfit(1:y,k,1);
                str=['���ζ�Ӧ������������ߣ�' 'y=' '(' num2str(numfit(1)) ')' '*x+' '(' num2str(numfit(2)) ')'];
            elseif(LPCval==2)
                numfit=polyfit(1:y,k,2);
                str=['���ζ�Ӧ������������ߣ�' 'y=' '(' num2str(numfit(1)) ')' '*x^2+' '(' num2str(numfit(2)) ')' '*x+' '(' num2str(numfit(3)) ')'];
            elseif(LPCval==3)
                numfit=polyfit(1:y,k,3);
                str=['���ζ�Ӧ������������ߣ�' 'y=' '(' num2str(numfit(1)) ')' '*x^3+' '(' num2str(numfit(2)) ')' '*x^2+' '(' num2str(numfit(2)) ')' '*x+' '(' num2str(numfit(3)) ')'];
            else
                str='Ϊ��ȷѡ����Ͻ״�';
            end
              set(handles.edit7,'String',str);
        end
%     end
    %% ���²���
    setappdata(handles.figure1, 'numRec', numRec); %�����ѽ��յ����ݸ���
    setappdata(handles.figure1, 'strRec', strRec); %����Ҫ��ʾ���ַ���
end

% --- Executes during object creation, after setting all properties.
function Com_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Com (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Rate.
function Rate_Callback(hObject, eventdata, handles)
% hObject    handle to Rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Rate contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Rate


% --- Executes during object creation, after setting all properties.
function Rate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Rate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in IPSelectPop.
function IPSelectPop_Callback(hObject, eventdata, handles)
% hObject    handle to IPSelectPop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns IPSelectPop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from IPSelectPop
val=get(handles.IPSelectPop,'value');   %�õ���ѡ���ֵ
if val==1   %disable all botton
    set(handles.ImageLoad, 'Enable', 'off');set(handles.fenge, 'Enable', 'off');set(handles.ErZhi, 'Enable', 'off');set(handles.ShiBie, 'Enable', 'off');
    set(handles.pushbutton19, 'Enable', 'off');set(handles.imcapturebotn, 'Enable', 'off');
    set(handles.IPComOpen, 'Enable', 'off');set(handles.pushbutton17, 'Enable', 'off');
    
    msgbox('Please Choice Camera Select "Local Image!"or other ones');
elseif val==2       %�򿪱���ͼƬ
    set(handles.pushbutton19, 'Enable', 'off');set(handles.imcapturebotn, 'Enable', 'off');set(handles.pushbutton17, 'Enable', 'off');
    set(handles.IPComOpen, 'Enable', 'off');
    
    set(handles.ImageLoad, 'Enable', 'on');set(handles.fenge, 'Enable', 'on');set(handles.ErZhi, 'Enable', 'on');set(handles.ShiBie, 'Enable', 'on');
elseif val==3       %��IP����ͷģʽ
    set(handles.ImageLoad, 'Enable', 'off');set(handles.fenge, 'Enable', 'off');set(handles.ErZhi, 'Enable', 'off');set(handles.ShiBie, 'Enable', 'off');
    set(handles.pushbutton19, 'Enable', 'off');set(handles.imcapturebotn, 'Enable', 'off');
    
    set(handles.IPComOpen, 'Enable', 'on');set(handles.pushbutton17, 'Enable', 'on');
elseif val==4       %��usb��������ͷģʽ
    set(handles.ImageLoad, 'Enable', 'off');set(handles.fenge, 'Enable', 'off');set(handles.ErZhi, 'Enable', 'off');set(handles.ShiBie, 'Enable', 'off');
    set(handles.IPComOpen, 'Enable', 'off')
    
    set(handles.pushbutton19, 'Enable', 'on');set(handles.imcapturebotn, 'Enable', 'on');set(handles.pushbutton17, 'Enable', 'on');
end

% --- Executes during object creation, after setting all properties.
function IPSelectPop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IPSelectPop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
scom = get(handles.figure1, 'UserData');
numSend = getappdata(handles.figure1, 'numSend');
val = get(handles.Sendedit, 'string');%sends
numSend = numSend + length(val);
set(handles.Sendedit, 'string', num2str(numSend));
setappdata(handles.figure1, 'numSend', numSend);
%% ��Ҫ���͵����ݲ�Ϊ�գ���������
if ~isempty(val)
    %% ���õ������ĳ�ֵ
    n = 1000;
    while n
        %% ��ȡ���ڵĴ���״̬��������û������д���ݣ�д������
        str = get(scom, 'TransferStatus');
        if ~(strcmp(str, 'write') || strcmp(str, 'read&write'))
%            fprintf(scom,'xuexi');
             fwrite(scom, val, 'uint8', 'async'); %����д�봮��
            break;
        end
        n = n - 1; %������
    end
end

% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);

% Delte all timers
% try
%     out = timerfind('Tag', 'Continuous Capture');
%     stop(out);
%     delete(out);
% catch exception
% end

% % web -browser http://www.ilovematlab.cn/thread-201914-1-1.html



function IPText_Callback(hObject, eventdata, handles)
% hObject    handle to IPText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of IPText as text
%        str2double(get(hObject,'String')) returns contents of IPText as a double


% --- Executes during object creation, after setting all properties.
function IPText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to IPText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in IPComOpen.
function IPComOpen_Callback(hObject, eventdata, handles)
% hObject    handle to IPComOpen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% try
%     
% timerObj = timer('Tag','Continuous Capture','period',video_fs);
% set(timerObj,'ExecutionMode','fixedrate','StartDelay',0.5);
% set(timerObj,'TimerFcn',{@UD_capture_image,hObject,handles});
% start(timerObj);    
%     
% end
global Imagecapflag;
Imagecapflag=0;
val=get(handles.IPSelectPop,'value'); 

 set(handles.CommentTxt,'visible','off');
if val~=3   
msgbox('Please Choice Camera Select "IP Camera !"') 
else
    axes(handles.axes1);    
        IPURL=get(handles.IPText,'string');
        IPim=imread(IPURL);
        imshow(IPim);
 %% ��IPͼ�����ʶ��       
    %% ��ʼ��
    
    IPim = imread(IPURL);
    Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
    Rpic=rgb2roicollect(IPim,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ
    pic=Rpic(:,:,1);
    image1=im2bw(pic,0.5);  %����ҶȻ���
    k=0;
    for idx=1:5
        pause(1);
         IPim = imread(IPURL);
        Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
        Rpic=rgb2roicollect(IPim,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ
        pic=Rpic(:,:,1);
        image1=im2bw(pic,0.5);
        a=rotate2rci(image1);   %����ת�Ƕȣ����������ת�ĽǶ�
        k=k+a;
    end
    a=k/5;    %����ͼ���ȡ����ת�Ƕ�ƽ��ֵ
    a=0;%%%����ҵ�2017-3-31
%% ���λ��Ƴ�ʼ��
cla(handles.boxing);
axes(handles.boxing);
% hold on;
% plot([0:1:99],[100:800]);

%% ����ͷʶͼ
    numstore=zeros(100,1);
    for idx = 1:100
        IPim = imread(IPURL);
        axes(handles.axes6);
        imshow(IPim);
        VediorgbImage1(:,:,1)=imrotate(IPim(:,:,1),a);
        VediorgbImage1(:,:,2)=imrotate(IPim(:,:,2),a);
        VediorgbImage1(:,:,3)=imrotate(IPim(:,:,3),a);
        if Imagecapflag == 1        %��־λ��⣬��⵽��־λ���˳���
            clear obj;
            Imagecapflag=5;
            break;
        end
        Imagecapflag=0;
%         try
            %����ת���ͼƬ���� object recongnize detect
            Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
            Rpic=rgb2roicollect(VediorgbImage1,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ            
            pic=Rpic(:,:,1);
            image1=im2bw(pic,0.9);        
            J1=image1;
            axes(handles.axes1);    
            imshow(J1);
   %% ��������ȡ���ͼ��ȥ��Ϊ�ָ���ı�ü�
            [m,~]=size(J1);
            J2=zeros(m,1);           
            for i=1:m
                J2(i)=sum(J1(i,:));
                if (J2(i)>3)
                break;
                end
            end
            
            for j=m:-1:i
                J2(j)=sum(J1(i,:));
                if (J2(j)>3)
                    break;
                end
            end
            image2=J1(i:j,:);
            
 %% ������ͷͼƬ��ר�ŵĴ���           
            [pict1,pict2,pict3,pict4,pict5]=cutup2picdel(image2);
            set(handles.edit1,'String',' ');
%             num1=image2num(pict1,1);
%             num2=image2num(pict2,1);
%             num3=image2num(pict3,1);
%             num4=image2num(pict4,1);
%             num5=image2num(pict5,1);
            num1=ImC2numORC(pict1);
            num2=ImC2numORC(pict2);
            num3=ImC2numORC(pict3);
            num4=ImC2numORC(pict4);
            num5=ImC2numORC(pict5);
            num_c=num1*10000+num2*1000+num3*100+num4*10+num5;%cuoqie(pict1)
 
            
%             str = num2str(num_c);
            str1= [num1 num2 num3 num4 num5];
            str=num2str(str1);
            set(handles.edit1,'String',str);
%             set(handles.edit1,'String',str);
            
            axes(handles.axes4);
            axes('position',[0.31,0.24,0.1,0.1]);
            imshow(pict1);
            axes('position',[0.36,0.24,0.1,0.1]);
            imshow(pict2);
            axes('position',[0.41,0.24,0.1,0.1]);
            imshow(pict3);
            axes('position',[0.46,0.24,0.1,0.1]);
            imshow(pict4);
            axes('position',[0.51,0.24,0.1,0.1]);
            imshow(pict5);
            pause(1);
%         pause(0.5);
        try
            if (Imagecapflag == 1)
                clear obj;
                Imagecapflag=5;
                break;
            end
        catch
            break;
        end
        numstore(idx)=num_c;
        

    end
    %%  �ⲿ�ֽ����еڶ�����
    %%  ���ݷ������Ʋ�������
%     val=get(handles.shujufx,'value');
%     if val==1
%         cla(handles.boxing);  %���Ʋ���ǰ���ͼ����Ϣ
%         axes(handles.boxing);  %�������������
%         plot(1:idx,numstore,'g.','markersize',25);
%         hold on;
%         %�������
%         num=polyfit(x,y,2);
%         y=num(1)*x.^2-num(2)*x+num(3);  %������Ϸ���
%         plot(x,y);
%         %��ʾ����
%         str='y=num(1)*x.^2-num(2)*x+num(3)';
%         datanum=num2str(num);
%         str(3)=datanum(1);
%         str(10)=datanum(2);
%         str(14)=datanum(3);
%         set(handles.edit7,'String',str);
%     end

end






% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% close IPCamera Function!
global Imagecapflag;    %����ͷ�򿪱�־��ʹ����ͷ�˳�
Imagecapflag=1;

% --- Executes on selection change in jiaoyan.
function jiaoyan_Callback(hObject, eventdata, handles)
% hObject    handle to jiaoyan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns jiaoyan contents as cell array
%        contents{get(hObject,'Value')} returns selected item from jiaoyan


% --- Executes during object creation, after setting all properties.
function jiaoyan_CreateFcn(hObject, eventdata, handles)
% hObject    handle to jiaoyan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in data_bits.
function data_bits_Callback(hObject, eventdata, handles)
% hObject    handle to data_bits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns data_bits contents as cell array
%        contents{get(hObject,'Value')} returns selected item from data_bits


% --- Executes during object creation, after setting all properties.
function data_bits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to data_bits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in stop_bits.
function stop_bits_Callback(hObject, eventdata, handles)
% hObject    handle to stop_bits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns stop_bits contents as cell array
%        contents{get(hObject,'Value')} returns selected item from stop_bits


% --- Executes during object creation, after setting all properties.
function stop_bits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stop_bits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object deletion, before destroying properties.
function SerialOpen_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to SerialOpen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function Sendedit_Callback(hObject, eventdata, handles)
% hObject    handle to Sendedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sendedit as text
%        str2double(get(hObject,'String')) returns contents of Sendedit as a double


% --- Executes during object creation, after setting all properties.
function Sendedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sendedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in shujufx.
function shujufx_Callback(hObject, eventdata, handles)
% hObject    handle to shujufx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of shujufx
val=get(handles.shujufx,'value');
if val==1
    set(handles.LPCtimes, 'Enable', 'on');
else
    set(handles.LPCtimes, 'Enable', 'off');
end

% --- Executes on button press in pushbutton19.
function pushbutton19_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA) 
global Imagecapflag;
global VediorgbImage;
global idx;
global kk;
global zhi1;
kk=0;
zhi1=0;
val=get(handles.IPSelectPop,'value');
if val~=4
    msgbox('Please Choice Camera Select "WebCamera !"');
    get(handles.IPSelectPop,'value');
    set(hObject, 'String', '��������ͷ');  %���ñ���ť�ı�Ϊ���رմ��ڡ�
else
    if get(hObject, 'value')    %����ǰ���������ֵΪ1
        
        set(hObject, 'String', '�رյ���');  %���ñ���ť�ı�Ϊ���رմ��ڡ�
        try
            obj=webcam('USB2.0 PC CAMERA');%����ͷѡ��
        catch
            obj=webcam('USB2.0 UVC HD Webcam');
        end
        
        Imagecapflag=4;
%         axes(handles.axeszf);
        for idx = 1:700
            VediorgbImage = snapshot(obj); % Acquire a single image.
            axes(handles.axes6);
            imshow(VediorgbImage);
            %% ����ͷͼ�����ʾ������ͷͼ���ROI������ȡ�Ͷ�ֵ��Ч����ʾ
            Rmin=180;Rmax=256;Gmin=0;Gmax=160;Bmin=0;Bmax=130;
            Rpic=rgb2roicollect(VediorgbImage,Rmin,Rmax,Gmin,Gmax,Bmin,Bmax);    %����Ȥ������ȡ
            axes(handles.axes2);    %�ָ���ͼƬ��ʾ
            imshow(Rpic);%
            pic=Rpic(:,:,1);
            zhi1=get(handles.erzhihuapop,'value');
            if zhi1==1
                zhi1=0.5;
            elseif(zhi1==2)
                zhi1=0.1;
            elseif(zhi1==3)
                zhi1=0.2;
            elseif(zhi1==4)
                zhi1=0.3;
            elseif(zhi1==5)
                zhi1=0.4;
            elseif(zhi1==6)
                zhi1=0.5;
            elseif(zhi1==7)
                zhi1=0.6;
            elseif(zhi1==8)
                zhi1=0.7;
            elseif(zhi1==9)
                zhi1=0.8;
            elseif(zhi1==10)
                zhi1=0.9;
            else 
                zhi1=0.95
            end
            image1=im2bw(pic,zhi1);  %����ҶȻ���
            axes(handles.axes3);    %�ָ���ͼƬ��ʾ
            imshow(image1);%
            %% �Ƴ�����ͷģʽ
            if kk==1
                clear obj;
                cla(handles.boxing);
                cla(handles.axes1);
                cla(handles.axes2);
                cla(handles.axes3);
                cla(handles.axeszf);
                cla(handles.axes4);
                cla(handles.axes6);
                break;
            end
        end
        
    else
        set(hObject, 'String', '��������ͷ');  %���ñ���ť�ı�Ϊ���رմ��ڡ�
%          set(handles.axeszf,'visible','off');
%         clear obj;
                %% �������ͼ��
        cla(handles.boxing);
        cla(handles.axes1);
        cla(handles.axes2);
        cla(handles.axes3);
        cla(handles.axeszf);
        cla(handles.axes4);
        cla(handles.axes6);
        
        kk=1;
    end
end



% --- Executes on key press with focus on pushbutton19 and none of its controls.
function pushbutton19_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in ImRecong.
function ImRecong_Callback(hObject, eventdata, handles)
% hObject    handle to ImRecong (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on selection change in LPCtimes.
function LPCtimes_Callback(hObject, eventdata, handles)
% hObject    handle to LPCtimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns LPCtimes contents as cell array
%        contents{get(hObject,'Value')} returns selected item from LPCtimes


% --- Executes during object creation, after setting all properties.
function LPCtimes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LPCtimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function Menu_Comment_Callback(hObject, eventdata, handles)
% hObject    handle to Menu_Comment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% �˲������ڹ���˵��
%% 
winopen('.\CHM.CHM')
% .\offset\qam16
% axes(handles.boxing);
% alert_led(3);



% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_close_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% �رղ��˳�
global Imagecapflag;
global idx;
idx=100;
Imagecapflag=1;
while(Imagecapflag==5)
    pause(1);
end
close all
clear all
close(gcf);


% --------------------------------------------------------------------
% function thenextfunc_Callback(hObject, eventdata, handles)
% % hObject    handle to thenextfunc (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 

% --- Executes on button press in isHexDisp.
function isHexDisp_Callback(hObject, eventdata, handles)
% hObject    handle to isHexDisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of isHexDisp


% --- Executes on button press in clearzone.
% function pushbutton22_Callback(hObject, eventdata, handles)
% % hObject    handle to clearzone (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in clearzone.
function clearzone_Callback(hObject, eventdata, handles)
% hObject    handle to clearzone (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
setappdata(handles.figure1, 'strRec', '');
set(handles.Recvedit, 'String', '');  %���ñ���ť�ı�Ϊ���򿪴��ڡ�



function rec_Callback(hObject, eventdata, handles)
% hObject    handle to rec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rec as text
%        str2double(get(hObject,'String')) returns contents of rec as a double


% --- Executes during object creation, after setting all properties.
function rec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function yuyincontrol_Callback(hObject, eventdata, handles)
% hObject    handle to yuyincontrol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% luyin
set(handles.figure1,'visible','off');
fprintf('Press any key to play the recording...\n');
pause; 
fprintf('Start recording.\n');
fs=8000; %����Ƶ�� 
recObj = audiorecorder(fs,16,1);
disp('Start speaking.');
recordblocking(recObj, 3);
disp('End of Recording.');
set(handles.figure1,'visible','on');
% Play back the recording.
% play(recObj);
% Store data in double-precision array.
myRecording = getaudiodata(recObj,'int16');
val=num2str(speechrecognition(uint8(myRecording)));

try 
%     get(handles.SerialOpen, 'value')
    scom = get(handles.figure1, 'UserData');
    fwrite(scom, val, 'uint8', 'async'); %����д�봮��
    
catch
    msgbox('Please ensure srial Com is open!');
end


% --- Executes on selection change in popupmenu9.
function popupmenu9_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu9 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu9


% --- Executes during object creation, after setting all properties.
function popupmenu9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





% --- Executes during object creation, after setting all properties.
function erzhihuapop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to erzhihuapop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
