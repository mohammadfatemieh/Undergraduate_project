﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace three
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process p = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
            psi.FileName = "C:/Users/Smriti Pertor/Desktop/GraduateDesigned_Last_Update/DDIR/for_testing/DDIR.exe";//程序
            //psi.Arguments = "E:s/WpfApplication1/WpfApplication1/1.txt";//参数
            p.StartInfo = psi;
            p.Start();
 

        }
    }
}
