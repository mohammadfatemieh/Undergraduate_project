#include "usart.h"
extern char bianliang_shumaguan;
unsigned char UART_buff[50]; 
/*------------------------------------------------
                    ���ڳ�ʼ��
------------------------------------------------*/
void InitUART(void)
{
    TMOD = 0x20;
    SCON = 0x50;
    TH1 = 0xFD;
    TL1 = TH1;
    PCON = 0x00;
    EA = 1;
    ES = 1;
    TR1 = 1;
}    


/*------------------------------------------------
                    ����һ���ֽ�
------------------------------------------------*/
void SendByte(unsigned char dat)
{
 SBUF = dat;
 while(!TI);
      TI = 0;
}

/*------------------------------------------------
                    ����һ���ַ���
------------------------------------------------*/
void SendStr(unsigned char *s)
{
 while(*s!='\0')// \0 ��ʾ�ַ���������־��
                //ͨ������Ƿ��ַ���ĩβ
  {
  SendByte(*s);
  s++;
  }
}
unsigned char count=0;
//----------------------------------------------  
void ser_int(void) interrupt 4   
{  
	
	
    if(RI == 1) {    
      RI = 0;       
      UART_buff[count] = SBUF;  
      if(UART_buff[count] == '1')  {bianliang_shumaguan=1;LED0 = 0; LED1 = 1; LED2 = 1; }		
      else if(UART_buff[count] == '2')  {bianliang_shumaguan=2;LED1 = 0; LED0 = 1;LED2 = 1; }		
			else if(UART_buff[count] == '3')  {bianliang_shumaguan=3;LED2 = 0; LED0 = 1; LED1 = 1;  }
			else if(UART_buff[count] == '4')  {bianliang_shumaguan=4;LED2 = 0; LED0 = 0; LED1 = 0;  }
			else {LED0 = 1; LED1 = 1; LED2 = 1; bianliang_shumaguan=0;}
			SendByte(SBUF);
    }  
    else  {        
      TI = 0;     
    }

if(UART_buff[count]=='b')
	count=0;
else count++;
}
