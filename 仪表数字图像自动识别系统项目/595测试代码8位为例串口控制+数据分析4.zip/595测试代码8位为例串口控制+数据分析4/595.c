#include <REG52.H>
#include "usart.h"

#define Num_Point		0x80		//��С����ķ���: Tab[x]|Num_Point			
char bianliang_shumaguan=0;
unsigned char code Tab[] = {0xc0,0xcf,0xa4,0xb0,0x99,0x92,0x82, 0xf8,0x80,
							0x90, 0x88,0x83,0xc6,0xa1,0x86,0x8e,0xff,0x7f};//0 1 2 3 4 5 6 7 8 9 A B C D F �� . //  ���������
//12029��14468��17133��20022��23136��26475��30039��33828��37842��42081��
//46545��51234��56148��61287��66651��72240��78054��84093��90357��96846
unsigned char code sjfx[20][5] ={{0xcf,0xa4,0xc0,0xa4,0x90},{0xcf,0x99,0x99,0x82,0x80},
{0xcf,0xf8,0xcf,0xb0,0xb0},{0xa4,0xc0,0xc0,0xa4,0xa4},{0xa4,0xb0,0xcf,0xb0,0x82},
{0xa4,0x82,0x99,0xf8,0x92},{0xb0,0xc0,0xc0,0xb0,0x90},{0xb0,0xb0,0x80,0xa4,0x80},
{0xb0,0xf8,0x80,0x99,0xa4},{0x99,0xa4,0xc0,0x80,0xcf},{0x99,0x82,0x92,0x99,0x92},
{0x92,0xcf,0xa4,0xb0,0x99},{0x92,0x82,0xcf,0x99,0x80},{0x82,0xcf,0xa4,0x80,0xf8},
{0x82,0x82,0x82,0x92,0xcf},{0xf8,0xa4,0xa4,0x99,0xc0},{0xf8,0x80,0xc0,0x92,0x99},
{0x80,0x99,0xc0,0xb0,0x90},{0x90,0xc0,0xc0,0x92,0xf8},{0x90,0x82,0x80,0x99,0x82}};
//h g f e d c b a
//	��λ->��λ


sbit  LOAD=P2^2;
sbit  CLK=P2^1;
sbit  SDK=P2^0;

sbit S4=P2^7;
sbit S3=P2^6;		
sbit S2=P2^5;
sbit S1=P2^4;							
unsigned char flag=0;
void show1(void);
void show2(void);
void show3(void);		
void show4(void);
	
void delay10ms(unsigned char temp)
{
	unsigned char i,j,t;
	t=temp;
	while(t!=0)
    {
		for(i=20;i>0;i--)
       	for(j=248;j>0;j--)
				{
					
				}
		t--;
	}
}

void SPI_595(unsigned char out_data)
{
	unsigned char i,temp;
 	for(i=0;i<8;i++)
  	{
		CLK=0;
     	temp=out_data&0x80;
     	if(temp==0x80)
        SDK=1;
        else SDK=0;    
     	out_data=out_data<<1;
     	CLK=1;
	}
}

char flag1=0;
char key_value(void)
{
	
	if(S4==0)
	{
		delay10ms(1);		
		if(S4==0)flag1=2;
	}
	else if(S3==0)
	{
			delay10ms(1);		
			if(S3==0)flag1=1;
	}
	else if(S2==0)
	{
			delay10ms(1);		
			if(S2==0)flag1=3;
	}
	else if(S1==0)
	{
			delay10ms(1);		
			if(S1==0)flag1=4;
	}	
	return flag1;
}

void main(void)
{  
		InitUART();
	
//		delay10ms(2);
//		while(S4==1&&S3==1&&S2==1)
//		{
//			delay10ms(1);		
//		}
//		if(S2==0)
//		{
//			flag=3;
//		}
//		else if(S3==0)
//		{
//			flag=1;
//		}
//		else if(S4==0)
//		{
//			flag=2;
//		}
    while(1)
    { 
				flag=bianliang_shumaguan;//key_value();
				if(flag==1)show1();	//ÿ��5λ��Ϊ��������һ������ֵ12345
				else if(flag==2) show2();	//00000
				else if (flag==3)show3();	//�����ʾ
				else if (flag==4)show4();	//���ص����ʾ�������ݷ���

	  } 
}


void show1(void)
{
		LOAD=1;
		LOAD=0;	
		delay10ms(500);

	SPI_595(Tab[4]);
	SPI_595(Tab[3]);
    SPI_595(Tab[2]);
	SPI_595(Tab[1]); 
	SPI_595(Tab[0]);
		LOAD=1;
		LOAD=0;	
		delay10ms(500);
	SPI_595(Tab[9]);
	SPI_595(Tab[8]);
	SPI_595(Tab[7]);
	SPI_595(Tab[6]);
	SPI_595(Tab[5]);
		LOAD=1;
		LOAD=0;
		delay10ms(500);
		SPI_595(Tab[9]);
	SPI_595(Tab[7]);
	SPI_595(Tab[5]);
	SPI_595(Tab[3]);
	SPI_595(Tab[1]);
		LOAD=1;
		LOAD=0;
				delay10ms(500);
		SPI_595(Tab[0]);
	SPI_595(Tab[8]);
	SPI_595(Tab[6]);
	SPI_595(Tab[4]);
	SPI_595(Tab[2]);
		LOAD=1;
		LOAD=0;
				delay10ms(500);
		SPI_595(Tab[3]);
	SPI_595(Tab[7]);
	SPI_595(Tab[3]);
	SPI_595(Tab[5]);
	SPI_595(Tab[2]);
		LOAD=1;
		LOAD=0;		
						delay10ms(500);
		SPI_595(Tab[8]);
	SPI_595(Tab[4]);
	SPI_595(Tab[3]);
	SPI_595(Tab[9]);
	SPI_595(Tab[1]);
		LOAD=1;
		LOAD=0;	
	//	SPI_595(Tab[15]);
	//	SPI_595(Tab[14]);
	//	SPI_595(Tab[13]);
	//	SPI_595(Tab[12]);
	//	SPI_595(Tab[11]);
	//    SPI_595(Tab[10]);
	//	SPI_595(Tab[9]); 
	//	SPI_595(Tab[8]);
	//	SPI_595(Tab[7]);
	//	SPI_595(Tab[6]);
	//	SPI_595(Tab[5]);
	//	LOAD=1;
	//	LOAD=0;
			delay10ms(2000);
}

void show2(void)
{
			LOAD=1;
			LOAD=0;	
			delay10ms(500);
			SPI_595(Tab[0]);
			SPI_595(Tab[0]);
				SPI_595(Tab[0]);
			SPI_595(Tab[0]); 
			SPI_595(Tab[0]);
			LOAD=1;
			LOAD=0;	
			delay10ms(500);
			SPI_595(Tab[1]);
			SPI_595(Tab[1]);
				SPI_595(Tab[1]);
			SPI_595(Tab[1]); 
			SPI_595(Tab[1]);
			LOAD=1;
			LOAD=0;
			delay10ms(500);
			SPI_595(Tab[2]);
			SPI_595(Tab[2]);
				SPI_595(Tab[2]);
			SPI_595(Tab[2]); 
			SPI_595(Tab[2]);
			LOAD=1;
			LOAD=0;
			delay10ms(500);
			SPI_595(Tab[3]);
			SPI_595(Tab[3]);
				SPI_595(Tab[3]);
			SPI_595(Tab[3]); 
			SPI_595(Tab[3]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[4]);
			SPI_595(Tab[4]);
				SPI_595(Tab[4]);
			SPI_595(Tab[4]); 
			SPI_595(Tab[4]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[5]);
			SPI_595(Tab[5]);
				SPI_595(Tab[5]);
			SPI_595(Tab[5]); 
			SPI_595(Tab[5]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[6]);
			SPI_595(Tab[6]);
				SPI_595(Tab[6]);
			SPI_595(Tab[6]); 
			SPI_595(Tab[6]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[7]);
			SPI_595(Tab[7]);
				SPI_595(Tab[7]);
			SPI_595(Tab[7]); 
			SPI_595(Tab[7]);
			LOAD=1;
			LOAD=0;	 
				delay10ms(500);
			SPI_595(Tab[8]);
			SPI_595(Tab[8]);
				SPI_595(Tab[8]);
			SPI_595(Tab[8]); 
			SPI_595(Tab[8]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[9]);
			SPI_595(Tab[9]);
				SPI_595(Tab[9]);
			SPI_595(Tab[9]); 
			SPI_595(Tab[9]);
			LOAD=1;
			LOAD=0;
				delay10ms(5000);
}
void show3(void)
{
			LOAD=1;
			LOAD=0;	
			delay10ms(500);
			SPI_595(Tab[3]);
			SPI_595(Tab[7]);
			SPI_595(Tab[4]);
			SPI_595(Tab[5]&0x7f); 
			SPI_595(Tab[7]);
			LOAD=1;
			LOAD=0;	
			delay10ms(500);
			SPI_595(Tab[1]);
			SPI_595(Tab[1]);
				SPI_595(Tab[4]&0x7f);
			SPI_595(Tab[1]); 
			SPI_595(Tab[0]);
			LOAD=1;
			LOAD=0;
			delay10ms(500);
			SPI_595(Tab[5]);
			SPI_595(Tab[2]);
				SPI_595(Tab[2]&0x7f);
			SPI_595(Tab[3]); 
			SPI_595(Tab[7]);
			LOAD=1;
			LOAD=0;
			delay10ms(500);
			SPI_595(Tab[3]);
			SPI_595(Tab[6]&0x7f);
				SPI_595(Tab[3]);
			SPI_595(Tab[3]); 
			SPI_595(Tab[3]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[7]);
			SPI_595(Tab[4]&0x7f);
				SPI_595(Tab[4]);
			SPI_595(Tab[4]); 
			SPI_595(Tab[4]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[5]);
			SPI_595(Tab[5]);
				SPI_595(Tab[5]&0x7f);
			SPI_595(Tab[5]); 
			SPI_595(Tab[5]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[6]);
			SPI_595(Tab[6]);
				SPI_595(Tab[6]&0x7f);
			SPI_595(Tab[6]); 
			SPI_595(Tab[6]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[7]);
			SPI_595(Tab[5]);
				SPI_595(Tab[6]);
			SPI_595(Tab[7]&0x7f); 
			SPI_595(Tab[9]);
			LOAD=1;
			LOAD=0;	 
				delay10ms(500);
			SPI_595(Tab[8]);
			SPI_595(Tab[2]);
				SPI_595(Tab[8]);
			SPI_595(Tab[1]&0x7f); 
			SPI_595(Tab[3]);
			LOAD=1;
			LOAD=0;
				delay10ms(500);
			SPI_595(Tab[9]);
			SPI_595(Tab[9]);
				SPI_595(Tab[9]&0x7f);
			SPI_595(Tab[9]); 
			SPI_595(Tab[9]);
			LOAD=1;
			LOAD=0;
			delay10ms(5000);
}
//12029��14468��17133��20022��23136��26475��30039��33828��37842��42081��46545��51234��56148��
//61287��66651��72240��7805484093��90357��96846
void show4(void)
{
	unsigned char i;
	for(i=0;i<20;i++)
	{
			LOAD=1;
			LOAD=0;	
			delay10ms(500);
			SPI_595(sjfx[i][4]);
			SPI_595(sjfx[i][3]);
			SPI_595(sjfx[i][2]);
			SPI_595(sjfx[i][1]); 
			SPI_595(sjfx[i][0]);
	}
		for(i=20;i>0;i--)
	{
			LOAD=1;
			LOAD=0;	
			delay10ms(500);
			SPI_595(sjfx[i][4]);
			SPI_595(sjfx[i][3]);
			SPI_595(sjfx[i][2]);
			SPI_595(sjfx[i][1]); 
			SPI_595(sjfx[i][0]);
	}
	delay10ms(500);
}