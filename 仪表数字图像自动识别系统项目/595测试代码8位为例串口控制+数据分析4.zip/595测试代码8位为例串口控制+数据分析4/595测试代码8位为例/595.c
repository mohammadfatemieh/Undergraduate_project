#include <REG51.H>
unsigned char code Tab[] = {0xc0,0xcf,0xa4,0xb0,0x99,0x92,0x82, 0xf8,0x80,
							0x90, 0x88,0x83,0xc6,0xa1,0x86,0x8e,0xff,0x7f};//0 1 2 3 4 5 6 7 8 9 A B C D F �� . //  ���������

sbit  LOAD=P1^0;
sbit  CLK=P1^1;
sbit  SDK=P1^2;

void delay10ms(unsigned char temp)
{
	unsigned char i,j,t;
	t=temp;
	while(t!=0)
    {
		for(i=20;i>0;i--)
       	for(j=248;j>0;j--);
		t--;
	}
}

 void SPI_595(unsigned char out_data)
{
	unsigned char i,temp;
 	for(i=0;i<8;i++)
  	{
		CLK=0;
     	temp=out_data&0x80;
     	if(temp==0x80)
        SDK=1;
        else SDK=0;    
     	out_data=out_data<<1;
     	CLK=1;
	}
}

void main(void)
{  
    while(1)
    {  
	LOAD=1;
	LOAD=0;	
	delay10ms(500);
	SPI_595(Tab[0]);
	SPI_595(Tab[0]);
	SPI_595(Tab[0]);
	SPI_595(Tab[0]);
	SPI_595(Tab[0]);
    SPI_595(Tab[0]);
	SPI_595(Tab[0]); 
	SPI_595(Tab[0]);
	LOAD=1;
	LOAD=0;	
	delay10ms(500);
	SPI_595(Tab[1]);
	SPI_595(Tab[1]);
	SPI_595(Tab[1]);
	SPI_595(Tab[1]);
	SPI_595(Tab[1]);
    SPI_595(Tab[1]);
	SPI_595(Tab[1]); 
	SPI_595(Tab[1]);
	LOAD=1;
	LOAD=0;
	delay10ms(500);
	SPI_595(Tab[2]);
	SPI_595(Tab[2]);
	SPI_595(Tab[2]);
	SPI_595(Tab[2]);
	SPI_595(Tab[2]);
    SPI_595(Tab[2]);
	SPI_595(Tab[2]); 
	SPI_595(Tab[2]);
	LOAD=1;
	LOAD=0;
	delay10ms(500);
	SPI_595(Tab[3]);
	SPI_595(Tab[3]);
	SPI_595(Tab[3]);
	SPI_595(Tab[3]);
	SPI_595(Tab[3]);
    SPI_595(Tab[3]);
	SPI_595(Tab[3]); 
	SPI_595(Tab[3]);
	LOAD=1;
	LOAD=0;
		delay10ms(500);
	SPI_595(Tab[4]);
	SPI_595(Tab[4]);
	SPI_595(Tab[4]);
	SPI_595(Tab[4]);
	SPI_595(Tab[4]);
    SPI_595(Tab[4]);
	SPI_595(Tab[4]); 
	SPI_595(Tab[4]);
	LOAD=1;
	LOAD=0;
		delay10ms(500);
	SPI_595(Tab[5]);
	SPI_595(Tab[5]);
	SPI_595(Tab[5]);
	SPI_595(Tab[5]);
	SPI_595(Tab[5]);
    SPI_595(Tab[5]);
	SPI_595(Tab[5]); 
	SPI_595(Tab[5]);
	LOAD=1;
	LOAD=0;
		delay10ms(500);
	SPI_595(Tab[6]);
	SPI_595(Tab[6]);
	SPI_595(Tab[6]);
	SPI_595(Tab[6]);
	SPI_595(Tab[6]);
    SPI_595(Tab[6]);
	SPI_595(Tab[6]); 
	SPI_595(Tab[6]);
	LOAD=1;
	LOAD=0;
		delay10ms(500);
	SPI_595(Tab[7]);
	SPI_595(Tab[7]);
	SPI_595(Tab[7]);
	SPI_595(Tab[7]);
	SPI_595(Tab[7]);
    SPI_595(Tab[7]);
	SPI_595(Tab[7]); 
	SPI_595(Tab[7]);
	LOAD=1;
	LOAD=0;	 
		delay10ms(500);
	SPI_595(Tab[8]);
	SPI_595(Tab[8]);
	SPI_595(Tab[8]);
	SPI_595(Tab[8]);
	SPI_595(Tab[8]);
    SPI_595(Tab[8]);
	SPI_595(Tab[8]); 
	SPI_595(Tab[8]);
	LOAD=1;
	LOAD=0;
		delay10ms(500);
	SPI_595(Tab[9]);
	SPI_595(Tab[9]);
	SPI_595(Tab[9]);
	SPI_595(Tab[9]);
	SPI_595(Tab[9]);
    SPI_595(Tab[9]);
	SPI_595(Tab[9]); 
	SPI_595(Tab[9]);
	LOAD=1;
	LOAD=0;
			delay10ms(500);
	SPI_595(Tab[7]);
	SPI_595(Tab[6]);
	SPI_595(Tab[5]);
	SPI_595(Tab[4]);
	SPI_595(Tab[3]);
    SPI_595(Tab[2]);
	SPI_595(Tab[1]); 
	SPI_595(Tab[0]);
	LOAD=1;
	LOAD=0;
		delay10ms(2000);
	SPI_595(Tab[15]);
	SPI_595(Tab[14]);
	SPI_595(Tab[13]);
	SPI_595(Tab[12]);
	SPI_595(Tab[11]);
    SPI_595(Tab[10]);
	SPI_595(Tab[9]); 
	SPI_595(Tab[8]);
	LOAD=1;
	LOAD=0;
		delay10ms(5000);

	} 
}

