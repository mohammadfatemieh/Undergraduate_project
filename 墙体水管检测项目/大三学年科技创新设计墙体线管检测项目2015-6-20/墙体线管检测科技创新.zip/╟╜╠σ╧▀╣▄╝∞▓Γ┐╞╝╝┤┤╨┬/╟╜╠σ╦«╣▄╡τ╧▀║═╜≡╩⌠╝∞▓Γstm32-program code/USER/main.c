#include "led.h"
#include "delay.h"
#include "sys.h"
#include "key.h"
#include "usart.h"
#include "wdg.h"
#include "timer.h"
#include "pwm.h"
#include "lcd.h"
#include "adc.h"

//ALIENTEK Mini STM32�����巶������13
//ADC ʵ��
//����ԭ��@ALIENTEK
//������̳:www.openedv.com
 
 void GPIO_CONFIGTIO_Init(void)
{
		GPIO_InitTypeDef  GPIO_InitStructure;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;
		GPIO_InitStructure.GPIO_Pin =GPIO_Pin_2;
		GPIO_InitStructure.GPIO_Speed =GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
}
 int main(void)
 {
	u16 adcx0,adcx1,adcx2;
	float temp;
	SystemInit();
	delay_init(72);	     //��ʱ��ʼ��
	NVIC_Configuration();
 	uart_init(9600);
 	LED_Init();
 	KEY_Init();
	LCD_Init();
	Adc_Init();
	GPIO_CONFIGTIO_Init();
	POINT_COLOR=RED;//��������Ϊ��ɫ 
//	LCD_ShowString(60,50,"Mini STM32");	
//	LCD_ShowString(60,70,"ADC TEST");	
//	LCD_ShowString(60,90,"ATOM@ALIENTEK");
//	LCD_ShowString(60,110,"2010/12/30");	
	//��ʾ��ʾ��Ϣ
	POINT_COLOR=BLUE;//��������Ϊ��ɫ
	//LCD_ShowString(60,130,"ADC_CH0_VAL:");	      
	//LCD_ShowString(60,150,"ADC_CH0_VOL:0.000V");	      
	while(1)
	{
		/////////////////////////////////////////////////////
		adcx0=Get_Adc(ADC_Channel_0);
		LCD_ShowNum(156,60,adcx0,4,16);//��ʾADC��ֵ
		if(adcx0>2000)
			LCD_ShowString(0,80,"Electric Wire!   ");	
		else 
			LCD_ShowString(0,80,"No Electrical !");
			//////////////////////////////////////////////////
		adcx1=Get_Adc(ADC_Channel_1);
		LCD_ShowNum(156,100,adcx1,4,16);//��ʾADC��ֵ
		if(adcx1>700)
				LCD_ShowString(0,120,"The metal is detection!     ");		
		else 
				LCD_ShowString(0,120,"The metal isn't detection!");
		////////////////////////////////////////////////////////
		adcx2=Get_Adc(ADC_Channel_2);
		LCD_ShowNum(156,140,adcx2,4,16);//��ʾADC��ֵ
		if(adcx2>2000)
			LCD_ShowString(0,160,"Be Seek!     ");	
		else 
			LCD_ShowString(0,160,"Water Pipe!");
		adcx0=0;
		adcx1=0;
		adcx2=0;
//		temp=(float)adcx*(3.3/4096);
//		adcx=temp;
//		LCD_ShowNum(156,150,adcx,1,16);//��ʾ��ѹֵ
//		temp-=adcx;
//		temp*=1000;
//		LCD_ShowNum(172,150,temp,3,16);

		
		LED0=!LED0;
		delay_ms(250);
	}

 }

